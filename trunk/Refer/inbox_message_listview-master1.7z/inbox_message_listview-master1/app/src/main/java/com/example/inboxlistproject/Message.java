package com.example.inboxlistproject;

public class Message {
	public String msgPerson, msgBody, msgNumber;
    public int msgCount, msgRead, msgId;
    public long msgDate;
}
