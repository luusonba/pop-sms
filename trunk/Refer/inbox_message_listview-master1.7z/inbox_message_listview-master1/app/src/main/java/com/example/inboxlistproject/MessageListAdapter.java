package com.example.inboxlistproject;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.net.Uri;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;

public class MessageListAdapter extends ArrayAdapter<Message> {
	private Context ctx;
	public ArrayList<Message> messageListArray;
	public MessageListAdapter(Context context, int textViewResourceId,
			ArrayList<Message> messageListArray) {
		super(context, textViewResourceId);
		this.messageListArray = messageListArray;
		this.ctx = context;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		Holder holder;
		View convertView1 = convertView;
		if (convertView1 == null) {
			holder = new Holder();
			LayoutInflater vi = (LayoutInflater) ctx
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView1 = vi.inflate(R.layout.message_list_item, null);
			holder.msgPerson = (TextView) convertView1.findViewById(R.id.txt_person);
			holder.msgBody = (TextView) convertView1.findViewById(R.id.txt_body);
            holder.msgDate = (TextView) convertView1.findViewById(R.id.txt_date);
            holder.msgCount = (TextView) convertView1.findViewById(R.id.txt_count);
            holder.msgPhoto = (ImageView)convertView1.findViewById(R.id.img_photo);
			convertView1.setTag(holder);
		} else {
			holder = (Holder) convertView1.getTag();
		}
		Message message = getItem(position);

		holder.msgPerson.setText(message.msgPerson);

		holder.msgBody.setText(message.msgBody);

        holder.msgDate.setText(MainActivity.getDate(ctx, message.msgDate));

        holder.msgCount.setText(message.msgCount + "");

        if(message.msgRead == 0) {
            holder.msgBody.setTypeface(null, Typeface.BOLD);
        }else {
            holder.msgBody.setTypeface(null, Typeface.NORMAL);
        }
        InputStream photoContact = getPhotoContact(message.msgNumber);
        if(photoContact != null) {
            holder.msgPhoto.setImageBitmap(BitmapFactory.decodeStream(photoContact));
        }
		return convertView1;
	}

    private InputStream getPhotoContact(String phoneNumber) {
        long contactID = getContactID(phoneNumber);
        Uri contactUri = ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, contactID);
        Uri photoUri = Uri.withAppendedPath(contactUri, ContactsContract.Contacts.Photo.CONTENT_DIRECTORY);
        Cursor cursor = ctx.getContentResolver().query(photoUri,
                new String[] {ContactsContract.Contacts.Photo.PHOTO}, null, null, null);
        if (cursor == null) {
            return null;
        }
        try {
            if (cursor.moveToFirst()) {
                byte[] data = cursor.getBlob(0);
                if (data != null) {
                    return new ByteArrayInputStream(data);
                }
            }
        } finally {
            cursor.close();
        }
        return null;
    }

    private long getContactID(String phoneNumber) {
        long contactID = 0;
        ContentResolver contentResolver = ctx.getContentResolver();

        Uri uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(phoneNumber));

        Cursor cursor =
                contentResolver.query(
                        uri,
                        new String[] {ContactsContract.PhoneLookup.DISPLAY_NAME, ContactsContract.PhoneLookup._ID},
                        null,
                        null,
                        null);

        if(cursor!=null) {
            while(cursor.moveToNext()){
                contactID = cursor.getLong(cursor.getColumnIndexOrThrow(ContactsContract.PhoneLookup._ID));
            }
            cursor.close();
        }
        return contactID;
    }

	@Override
	public int getCount() {
		return messageListArray.size();
	}

	@Override
	public Message getItem(int position) {
		return messageListArray.get(position);
	}

	public void setArrayList(ArrayList<Message> messageList) {
		this.messageListArray = messageList;
		notifyDataSetChanged();
	}

	private class Holder {
		public TextView msgPerson, msgBody, msgDate, msgCount;
        public ImageView msgPhoto;
	}
}