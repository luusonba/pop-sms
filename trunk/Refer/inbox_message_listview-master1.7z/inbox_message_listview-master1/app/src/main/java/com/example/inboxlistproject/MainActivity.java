package com.example.inboxlistproject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.provider.BaseColumns;
import android.provider.CallLog;
import android.provider.ContactsContract.PhoneLookup;
import android.text.format.DateFormat;
import android.util.Log;
import android.widget.ListView;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Calendar;

public class MainActivity extends Activity {
    private ListView messageList;
    private MessageListAdapter messageListAdapter;
    private ArrayList<Message> recordsStored;
    private ArrayList<Message> listInboxMessages;
    private ProgressDialog progressDialogInbox;
    private CustomHandler customHandler;

    /**
     * Prefernece's name: show full date and time.
     */
    static final String PREFS_FULL_DATE = "show_full_date";

    /**
     * Minimum date.
     */
    public static final long MIN_DATE = 10000000000L;

    /**
     * Miliseconds per seconds.
     */
    public static final long MILLIS = 1000L;

    /**
     * {@link Calendar} holding today 00:00.
     */
    private static final Calendar CAL_DAYAGO = Calendar.getInstance();

    static {
        // Get time for now - 24 hours
        CAL_DAYAGO.add(Calendar.DAY_OF_MONTH, -1);
    }

    /**
     * {@link Uri} to all threads.
     */
    static final Uri URI_SIMPLE = Uri.parse("content://mms-sms/conversations").buildUpon()
            .appendQueryParameter("simple", "true").build();

    /**
     * Id.
     */
    public static final String ID = BaseColumns._ID;
    /**
     * Date.
     */
    public static final String DATE = CallLog.Calls.DATE;
    /**
     * count.
     */
    public static final String COUNT = "message_count";
    /**
     * number id.
     */
    public static final String NID = "recipient_ids";
    /**
     * body.
     */
    public static final String BODY = "snippet";
    /**
     * read.
     */
    public static final String READ = "read";

    /**
     * INDEX: id.
     */
    public static final int INDEX_SIMPLE_ID = 0;
    /**
     * INDEX: date.
     */
    public static final int INDEX_SIMPLE_DATE = 1;
    /**
     * INDEX: count.
     */
    public static final int INDEX_SIMPLE_COUNT = 2;
    /**
     * INDEX: person id.
     */
    public static final int INDEX_SIMPLE_NID = 3;
    /**
     * INDEX: body.
     */
    public static final int INDEX_SIMPLE_BODY = 4;
    /**
     * INDEX: read.
     */
    public static final int INDEX_SIMPLE_READ = 5;

    /**
     * Cursor's projection.
     */
    public static final String[] PROJECTION_SIMPLE = { //
            ID, // 0
            DATE, // 1
            COUNT, // 2
            NID, // 3
            BODY, // 4
            READ, // 5
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();
    }

    @Override
    public void onResume() {
        super.onResume();
        populateMessageList();
    }

    private void initViews() {
        customHandler = new CustomHandler(this);
        progressDialogInbox = new ProgressDialog(this);

        recordsStored = new ArrayList<Message>();

        messageList = (ListView) findViewById(R.id.messageList);
        populateMessageList();
    }

    public void populateMessageList() {
        fetchInboxMessages();

        messageListAdapter = new MessageListAdapter(this,
                R.layout.message_list_item, recordsStored);
        messageList.setAdapter(messageListAdapter);
    }

    private void showProgressDialog(String message) {
        progressDialogInbox.setMessage(message);
        progressDialogInbox.setIndeterminate(true);
        progressDialogInbox.setCancelable(true);
        progressDialogInbox.show();
    }

    private void fetchInboxMessages() {
        if (listInboxMessages == null) {
            showProgressDialog("Fetching Inbox Messages...");
            startThread();
        } else {
            // messageType = TYPE_INCOMING_MESSAGE;
            recordsStored = listInboxMessages;
            messageListAdapter.setArrayList(recordsStored);
        }
    }

    public class FetchMessageThread extends Thread {

        public int tag = -1;

        public FetchMessageThread(int tag) {
            this.tag = tag;
        }

        @Override
        public void run() {

            recordsStored = fetchInboxSms();
            //recordsStored = fetchInboxSms(TYPE_ALL_MESSAGE);
            listInboxMessages = recordsStored;
            customHandler.sendEmptyMessage(0);

        }

    }

    //public ArrayList<Message> fetchInboxSms(int type) {
    public ArrayList<Message> fetchInboxSms() {
        ArrayList<Message> smsInbox = new ArrayList<Message>();

        Cursor cursor = this.getContentResolver()
                .query(URI_SIMPLE,
                        PROJECTION_SIMPLE, null, null,
                        "date desc");

        if (cursor != null) {
            cursor.moveToFirst();
            if (cursor.getCount() > 0) {
                do {
                    Message message = new Message();
                    message.msgBody = cursor.getString(INDEX_SIMPLE_BODY);
                    message.msgDate = cursor.getLong(INDEX_SIMPLE_DATE);
                    message.msgCount = cursor.getInt(INDEX_SIMPLE_COUNT);
                    message.msgRead = cursor.getInt(INDEX_SIMPLE_READ);

                    message.msgNumber = getContactNumber(cursor.getInt(INDEX_SIMPLE_NID));
                    String person = getContactName(getContactNumber(cursor.getInt(INDEX_SIMPLE_NID)));

                    if (person != null) {
                        message.msgPerson = person;
                    } else {
                        message.msgPerson = message.msgNumber;
                    }

                    smsInbox.add(message);
                } while (cursor.moveToNext());
            }
        }
        return smsInbox;
    }

    public String getContactName(String phoneNumber) {
        ContentResolver cr = getContentResolver();
        Uri uri = Uri.withAppendedPath(PhoneLookup.CONTENT_FILTER_URI,
                Uri.encode(phoneNumber));
        Cursor cursor = cr.query(uri,
                new String[] { PhoneLookup.DISPLAY_NAME }, null, null, null);
        if (cursor == null) {
            return null;
        }
        String contactName = null;
        if (cursor.moveToFirst()) {
            contactName = cursor.getString(cursor
                    .getColumnIndex(PhoneLookup.DISPLAY_NAME));
        }
        if (cursor != null && !cursor.isClosed()) {
            cursor.close();
        }
        return contactName;
    }

    private String getContactNumber(final long recipientId) {
        String number = null;
        Cursor c = getContentResolver().query(ContentUris
                        .withAppendedId(Uri.parse("content://mms-sms/canonical-address"), recipientId),
                null, null, null, null);
        if (c.moveToFirst()) {
            number = c.getString(0);
        }
        c.close();
        return number;
    }

	private FetchMessageThread fetchMessageThread;

	private int currentCount = 0;

	public synchronized void startThread() {

		if (fetchMessageThread == null) {
			fetchMessageThread = new FetchMessageThread(currentCount);
			fetchMessageThread.start();
		}
	}

	public synchronized void stopThread() {
		if (fetchMessageThread != null) {
			Log.i("Cancel thread", "stop thread");
			FetchMessageThread moribund = fetchMessageThread;
			currentCount = fetchMessageThread.tag == 0 ? 1 : 0;
			fetchMessageThread = null;
			moribund.interrupt();
		}
	}

	static class CustomHandler extends Handler {
		private final WeakReference<MainActivity> activityHolder;

		CustomHandler(MainActivity inboxListActivity) {
			activityHolder = new WeakReference<MainActivity>(inboxListActivity);
		}

		@Override
		public void handleMessage(android.os.Message msg) {

			MainActivity inboxListActivity = activityHolder.get();
			if (inboxListActivity.fetchMessageThread != null
					&& inboxListActivity.currentCount == inboxListActivity.fetchMessageThread.tag) {
				Log.i("received result", "received result");
				inboxListActivity.fetchMessageThread = null;
				
				inboxListActivity.messageListAdapter
						.setArrayList(inboxListActivity.recordsStored);
				inboxListActivity.progressDialogInbox.dismiss();
			}
		}
	}

	private OnCancelListener dialogCancelListener = new OnCancelListener() {

		@Override
		public void onCancel(DialogInterface dialog) {
			stopThread();
		}

	};

    /**
     * Convert time into formated date.
     *
     * @param context {@link Context}
     * @param time    time
     * @return formated date.
     */
    static String getDate(final Context context, final long time) {
        long t = time;
        if (t < MIN_DATE) {
            t *= MILLIS;
        }
        if (PreferenceManager.getDefaultSharedPreferences(context).getBoolean(
                PREFS_FULL_DATE, false)) {
            return DateFormat.getTimeFormat(context).format(t) + " "
                    + DateFormat.getDateFormat(context).format(t);
        } else if (t < CAL_DAYAGO.getTimeInMillis()) {
            return DateFormat.getDateFormat(context).format(t);
        } else {
            return DateFormat.getTimeFormat(context).format(t);
        }
    }
}