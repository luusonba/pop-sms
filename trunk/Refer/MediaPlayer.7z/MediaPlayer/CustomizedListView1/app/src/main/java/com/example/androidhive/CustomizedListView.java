package com.example.androidhive;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.BaseColumns;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Calendar;

public class CustomizedListView extends Activity {
	// All static variables
	static final String URL = "http://api.androidhive.info/music/music.xml";
	// XML node keys
	static final String KEY_SONG = "song"; // parent node
	static final String KEY_ID = "id";
	static final String KEY_TITLE = "title";
	static final String KEY_ARTIST = "artist";
	static final String KEY_DURATION = "duration";
	static final String KEY_THUMB_URL = "thumb_url";

    /**
     * Prefernece's name: show full date and time.
     */
    static final String PREFS_FULL_DATE = "show_full_date";

    /**
     * Minimum date.
     */
    public static final long MIN_DATE = 10000000000L;

    /**
     * Miliseconds per seconds.
     */
    public static final long MILLIS = 1000L;

    /**
     * {@link java.util.Calendar} holding today 00:00.
     */
    private static final Calendar CAL_DAYAGO = Calendar.getInstance();

    static {
        // Get time for now - 24 hours
        CAL_DAYAGO.add(Calendar.DAY_OF_MONTH, -1);
    }

    /**
     * {@link android.net.Uri} to all threads.
     */
    static final Uri URI_SIMPLE = Uri.parse("content://mms-sms/conversations").buildUpon()
            .appendQueryParameter("simple", "true").build();

    /**
     * Id.
     */
    public static final String ID = BaseColumns._ID;
    /**
     * Date.
     */
    public static final String DATE = CallLog.Calls.DATE;
    /**
     * count.
     */
    public static final String COUNT = "message_count";
    /**
     * number id.
     */
    public static final String NID = "recipient_ids";
    /**
     * body.
     */
    public static final String BODY = "snippet";
    /**
     * read.
     */
    public static final String READ = "read";

    /**
     * INDEX: id.
     */
    public static final int INDEX_SIMPLE_ID = 0;
    /**
     * INDEX: date.
     */
    public static final int INDEX_SIMPLE_DATE = 1;
    /**
     * INDEX: count.
     */
    public static final int INDEX_SIMPLE_COUNT = 2;
    /**
     * INDEX: person id.
     */
    public static final int INDEX_SIMPLE_NID = 3;
    /**
     * INDEX: body.
     */
    public static final int INDEX_SIMPLE_BODY = 4;
    /**
     * INDEX: read.
     */
    public static final int INDEX_SIMPLE_READ = 5;

    /**
     * Cursor's projection.
     */
    public static final String[] PROJECTION_SIMPLE = { //
            ID, // 0
            DATE, // 1
            COUNT, // 2
            NID, // 3
            BODY, // 4
            READ, // 5
    };
	
	ListView list;
    LazyAdapter adapter;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		

		//ArrayList<HashMap<String, String>> songsList = new ArrayList<HashMap<String, String>>();

        ArrayList<Message> songsList = new ArrayList<Message>();

        songsList = getInboxSms();

		list=(ListView)findViewById(R.id.list);
		
		// Getting adapter by passing xml data ArrayList
        adapter=new LazyAdapter(this, songsList);        
        list.setAdapter(adapter);
        

        // Click event for single list row
        list.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
							

			}
		});		
	}

    public ArrayList<Message> getInboxSms() {
        ArrayList<Message> smsInbox = new ArrayList<Message>();

        Cursor cursor = this.getContentResolver()
                .query(URI_SIMPLE,
                        PROJECTION_SIMPLE, null, null,
                        "date desc");

        if (cursor != null) {
            cursor.moveToFirst();
            if (cursor.getCount() > 0) {
                do {
                    Message message = new Message();
                    message.msgBody = cursor.getString(INDEX_SIMPLE_BODY);
                    message.msgDate = cursor.getLong(INDEX_SIMPLE_DATE);
                    message.msgCount = cursor.getInt(INDEX_SIMPLE_COUNT);
                    message.msgRead = cursor.getInt(INDEX_SIMPLE_READ);

                    message.msgNumber = getContactNumber(cursor.getInt(INDEX_SIMPLE_NID));
                    String person = getContactName(getContactNumber(cursor.getInt(INDEX_SIMPLE_NID)));

                    if (person != null) {
                        message.msgPerson = person;
                    } else {
                        message.msgPerson = message.msgNumber;
                    }

                    smsInbox.add(message);
                } while (cursor.moveToNext());
            }
        }
        return smsInbox;
    }

    public String getContactName(String phoneNumber) {
        ContentResolver cr = getContentResolver();
        Uri uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
                Uri.encode(phoneNumber));
        Cursor cursor = cr.query(uri,
                new String[] { ContactsContract.PhoneLookup.DISPLAY_NAME }, null, null, null);
        if (cursor == null) {
            return null;
        }
        String contactName = null;
        if (cursor.moveToFirst()) {
            contactName = cursor.getString(cursor
                    .getColumnIndex(ContactsContract.PhoneLookup.DISPLAY_NAME));
        }
        if (cursor != null && !cursor.isClosed()) {
            cursor.close();
        }
        return contactName;
    }

    private String getContactNumber(final long recipientId) {
        String number = null;
        Cursor c = getContentResolver().query(ContentUris
                        .withAppendedId(Uri.parse("content://mms-sms/canonical-address"), recipientId),
                null, null, null, null);
        if (c.moveToFirst()) {
            number = c.getString(0);
        }
        c.close();
        return number;
    }
}