/** Automatically generated file. DO NOT MODIFY */
package com.example.inboxlistproject;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}