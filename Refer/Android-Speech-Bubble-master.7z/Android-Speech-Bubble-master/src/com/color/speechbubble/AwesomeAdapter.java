package com.color.speechbubble;

import java.util.ArrayList;

import android.content.Context;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
/**
 * AwesomeAdapter is a Custom class to implement custom row in ListView
 * 
 * @author Adil Soomro
 *
 */
public class AwesomeAdapter extends BaseAdapter{
	private Context mContext;
	private ArrayList<Message> mMessages;



	public AwesomeAdapter(Context context, ArrayList<Message> messages) {
		super();
		this.mContext = context;
		this.mMessages = messages;
	}
	@Override
	public int getCount() {
		return mMessages.size();
	}
	@Override
	public Object getItem(int position) {		
		return mMessages.get(position);
	}
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		Message message = (Message) this.getItem(position);

		ViewHolder holder; 
		if(convertView == null)
		{
			holder = new ViewHolder();
			convertView = LayoutInflater.from(mContext).inflate(R.layout.sms_row, parent, false);
			holder.message = (TextView) convertView.findViewById(R.id.message_text);
			holder.status = (TextView) convertView.findViewById(R.id.status_text);
			convertView.setTag(holder);
		}
		else
			holder = (ViewHolder) convertView.getTag();
		
		holder.message.setText(message.getMessage());
		//holder.status ;
		
		LayoutParams lp = (LayoutParams) holder.message.getLayoutParams();
		LayoutParams lpStatus = (LayoutParams) holder.status.getLayoutParams();
		if(message.isStatusMessage())
		{
			lp.gravity = Gravity.LEFT; 
			holder.message.setTextColor(mContext.getResources().getColor(R.color.textStatusColor));
		}
		else
		{		
			if(message.isMine())
			{
				lp.gravity = Gravity.RIGHT;
				lpStatus.gravity = Gravity.RIGHT;
				lp.setMargins(25, 5, 5, 0);
				lpStatus.setMargins(25, 3, 5, 0);
				holder.message.setTextColor(mContext.getResources().getColor(R.color.textMineColor));				
			}
			else
			{				
				lp.gravity = Gravity.LEFT;
				lpStatus.gravity = Gravity.LEFT;
				lp.setMargins(5, 5, 25, 0);
				lpStatus.setMargins(5, 3, 25, 0);
				holder.message.setTextColor(mContext.getResources().getColor(R.color.textYourColor));
			}
			holder.message.setLayoutParams(lp);			
		}
		return convertView;
	}
	private static class ViewHolder
	{
		TextView message;
		TextView status;
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

}
