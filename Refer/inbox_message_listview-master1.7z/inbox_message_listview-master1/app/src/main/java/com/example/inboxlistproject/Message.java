package com.example.inboxlistproject;

public class Message {
	public String msgNID, msgBody;
    public int msgCount, msgRead, msgId;
    public long msgDate;
}
