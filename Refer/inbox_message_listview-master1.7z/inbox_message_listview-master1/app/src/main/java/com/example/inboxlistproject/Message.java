package com.example.inboxlistproject;

public class Message {
	public String messageNumber, messageContent;
}
